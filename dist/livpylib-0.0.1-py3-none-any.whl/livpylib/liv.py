import subprocess
import sys
from importlib import import_module

# __all__ = []

def get_options():
    print(
        """
        Options for library imports:
        - plot
        - stats
        - images
        - formatting
        - geo
        - all
        - default
        """
    )

class lib_list():
    def __init__(self, types=None):
        self.libs = {
            'pandas':'pd',
            'math':None,
            'numpy':'np',
            'time':None,
            'datetime':None,
            'glob.glob':'glob',
            'os':None,
            'sys':None
        }
        if types:
            if isinstance(types, str):
                self.handle(types)
            if isinstance(types, list):
                for each in types:
                    self.handle(each)
        
        for lib,alias in self.libs.items():
            self._install_lib(lib,alias)
            
    def handle(self, types):
        match types:
            case 'plot':
                self._add_plot_libs()
            case 'stats':
                self._add_stats_libs()
            case 'images':
                self._add_images_libs()
            case 'formatting':
                self._add_formatting_libs()
            case 'geo':
                self._add_geo_libs()
            case 'all':
                self._add_all_libs()
            case 'default':
                pass
            case _:
                print(f'Could not find a type or none given.\n Loading default libs. Looking for more options?\n\n')
                get_options()
                return
        print(f'Loaded {types} libs')

    # These just need to add to the self.libs list
    def _add_plot_libs(self):
        self.libs['matplotlib.pyplot'] = 'plt'
        self.libs['seaborn']='sns'
        self.libs['matplotlib.patches'] = 'patches'
        self.libs['matplotlib.colors']='mcolors'
        self.libs['matplotlib.ticker']='mtick'
    def _add_stats_libs(self):
        self.libs['scipy.stats'] = 'stats'
        self.libs['statsmodels.api']='sm'
        self.libs['statsmodels']=None
        self.libs['statsmodels.formula.api']='smf'
        self.libs['scipy.optimize.curve_fit']='curve_fit'
        self.libs['scipy.stats.shapiro']='shapiro'
    def _add_images_libs(self):
        self.libs['PIL']=None
        self.libs['cv2']=None
    def _add_formatting_libs(self):
        self.libs['textwrap']=None
    def _add_geo_libs(self):
        self.libs['geopandas']='gpd'
        self.libs['geodatasets']=None
    def _add_all_libs(self):
        self._add_plot_libs()
        self._add_stats_libs()
        self._add_images_libs()
        self._add_formatting_libs()
        self._add_geo_libs()

    def _install_lib(self, lib_name, alias=None):
        try:
            import_module(lib_name)
        except ModuleNotFoundError:
            try:
                subprocess.check_call([sys.executable, '-m','pip','install',lib_name.split('.')[0]])
                try:
                    import_module(lib_name)
                except ModuleNotFoundError:
                    print(f'Error with {lib_name}: wont import')
            except subprocess.CalledProcessError as e:
                print(f'Error installing {lib_name}: {e}')
                print(f'Try installing {lib_name} manually and try again!')
        if alias:
            exec(f'{alias} = import_module({lib_name})', globals(), globals())
            # __all__.append(alias)
        else:
            exec(f'import_module({lib_name})', globals(), globals())
            # __all__.append(lib_name)
        

def lib(types=None):
    l = lib_list(types)

