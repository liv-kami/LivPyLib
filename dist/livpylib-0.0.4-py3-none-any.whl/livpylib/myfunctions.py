def test_function():
    print('The function works!')
    return